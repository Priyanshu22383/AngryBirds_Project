package inputs;

import game_options.GameStats;
import main.Pannel;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class MouseMoves implements MouseListener, MouseMotionListener {
    private Pannel pannel;
    public MouseMoves(Pannel pannel) {
        this.pannel = pannel;
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        System.out.println("Mouse Clicked");
//        switch (GameStats.state1) {
//            case GAMELOADPAGE:
//                pannel.getMainGame().getGameLoadPage().mouseClicked(e);
//                break;
//            case PLAYING:
//                pannel.getMainGame().getPlay().mouseClicked(e);
//                break;
//            case SETTINGS:
//                pannel.getMainGame().getSettings().mouseClicked(e);
//                break;
//            default:
//                break;
//
//        }
    }
    @Override
    public void mousePressed(MouseEvent e) {

    }
    @Override
    public void mouseReleased(MouseEvent e) {

    }
    @Override
    public void mouseEntered(MouseEvent e) {

    }
    @Override
    public void mouseExited(MouseEvent e) {

    }
    @Override
    public void mouseDragged(MouseEvent e) {

    }
    @Override
    public void mouseMoved(MouseEvent e) {

        pannel.setRectPos(e.getX(), e.getY());
    }
}
