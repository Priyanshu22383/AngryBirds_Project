package inputs;

import main.Pannel;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Keyinns implements KeyListener {
    private Pannel pannel;
    public Keyinns(Pannel pannel) {
        this.pannel = pannel;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_A:
                System.out.println("Left");
                pannel.updateXval(-5);
                break;
            case KeyEvent.VK_D:
                System.out.println("Right");
                pannel.updateXval(+5);
                break;
            case KeyEvent.VK_W:
                System.out.println("Up");
                pannel.updateYval(-5);
                break;
            case KeyEvent.VK_S:
                System.out.println("Down");
                pannel.updateYval(+5);
                break;
        }
    }
    @Override
    public void keyReleased(KeyEvent e) {
    }
}
