package game_options;

import main.MainGame;

import java.awt.*;
import java.awt.event.MouseEvent;

public class Settings {
    public Settings(MainGame mainGame) {
    }

    public void mouseClicked(MouseEvent e) {
    }

    public void updates() {

    }

    public void draw(Graphics g) {
    }
}
