package game_options;

public enum GameStats {
    GAMELOADPAGE,SETTINGS,PLAYING;
    public static GameStats state1=GAMELOADPAGE;
    public static GameStats state2=SETTINGS;
    public static GameStats state3=PLAYING;

}
