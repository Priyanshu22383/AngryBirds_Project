package game_options;

import main.MainGame;
import main.Pannel;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

public class Play extends State implements Statemethods{
    public Play(MainGame game) {
        super(game);
    }

    @Override
    public void updates() {

    }

    @Override
    public void draw(Graphics g) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    private void setATTACK(boolean b) {
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        Pannel pannel = new Pannel(this.getGame());
        switch (e.getKeyCode()){
            case KeyEvent.VK_A:
                System.out.println("Left");
                pannel.updateXval(-5);
                break;
            case KeyEvent.VK_D:
                System.out.println("Right");
                pannel.updateXval(+5);
                break;
            case KeyEvent.VK_W:
                System.out.println("Up");
                pannel.updateYval(-5);
                break;
            case KeyEvent.VK_S:
                System.out.println("Down");
                pannel.updateYval(+5);
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }
    public void windowFocusLost(){

    }
    public Play getPlay(){
        return this;
    }
}
