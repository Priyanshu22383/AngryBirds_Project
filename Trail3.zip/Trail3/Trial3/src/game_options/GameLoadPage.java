package game_options;
import main.Pannel;

import main.MainGame;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.Serializable;

public class GameLoadPage extends State implements Statemethods{
    private BufferedImage bg_img_ele2;
    private Rectangle buttonBound;
    private MainGame game;
    public GameLoadPage(MainGame game) {
        super(game);
        this.game=game;
        Pannel pannel = new Pannel(game);
        buttonBound = new Rectangle(20,35,35,35);
    }

    @Override
    public void updates() {

    }

    @Override
    public void draw(Graphics g) {
//        if (bg_img_ele2 != null) {
//            g.drawImage(bg_img_ele2, buttonBound.x, buttonBound.y, buttonBound.width, buttonBound.height, null);
//        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }
}
