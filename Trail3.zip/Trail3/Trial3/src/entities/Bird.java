package entities;

public class Bird extends Entity {
    public Bird(float x, float y) {
        super(x, y);
    }
    public void update() {

    }
    public void render() {

    }
}
