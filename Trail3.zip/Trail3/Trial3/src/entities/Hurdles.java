package entities;

public class Hurdles {
    public Hurdles(float x, float y) {

    }
    public void update() {

    }
    public void render() {

    }
}
