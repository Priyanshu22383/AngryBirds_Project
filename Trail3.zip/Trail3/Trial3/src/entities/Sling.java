package entities;

public class Sling {
    public Sling(){

    }
    public void update() {

    }
    public void render() {

    }
}
