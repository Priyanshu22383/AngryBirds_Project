package entities;

public class Pigs {
    public Pigs(){

    }
    public void update() {

    }
    public void render() {

    }
}
