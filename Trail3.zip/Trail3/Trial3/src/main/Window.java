package main;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class Window extends JFrame {
    private JFrame frame;
    public Window(Pannel pannel) {
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(pannel);
        frame.setLocationRelativeTo(null);
        frame.setResizable(true);
        frame.pack();
        frame.add(createImageButton("assets/play.png"));
        frame.setVisible(true);
    }

    private static JButton createImageButton(String resource) {
        JButton button = new JButton();
        try (InputStream is = Window.class.getClassLoader().getResourceAsStream(resource)) {
            if (is == null) {
                throw new IOException("Resource not found: " + resource);
            }
            BufferedImage icon = ImageIO.read(is);
            button.setIcon(new ImageIcon(icon));
        } catch (IOException e) {
            e.printStackTrace(); // Handle the error appropriately
        }
        return button;
    }
}
