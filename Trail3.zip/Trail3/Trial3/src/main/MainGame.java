package main;

import game_options.GameLoadPage;
import game_options.GameStats;
import game_options.Play;
import game_options.Settings;

import java.awt.*;
import java.awt.event.MouseListener;

public class MainGame {
    private Window window;
    private Pannel pannel;
    private Settings settings;
    private GameLoadPage gameload;
    private Play play;
    public MainGame() {
        pannel = new Pannel(this);
        window = new Window(pannel);
        gameload = new GameLoadPage(this);
        play = new Play(this);
        settings = new Settings(this);
        pannel.requestFocus();
    }
//    public void updates(){
//        switch (GameStats.state1){
//            case GAMELOADPAGE:
//                gameload.updates();
//                break;
//            case SETTINGS:
//                settings.updates();
//                break;
//            case PLAYING:
//                play.updates();
//                break;
//            default:
//                break;
//            }
//        }
//    public void windowFocusLost(){
//        if(GameStats.state1 == GameStats.PLAYING){
//            play.getPlay();
//        }
//    }
//    public void render(Graphics g){
//        switch (GameStats.state1){
//            case GAMELOADPAGE:
//                gameload.draw(g);
//                break;
//            case SETTINGS:
//                settings.draw(g);
////                settings.updates();
//                break;
//            case PLAYING:
//                play.draw(g);
////                playing.updates();
//                break;
//            default:
//                break;
//        }
//    }
//    public GameLoadPage getGameLoadPage(){
//        return gameload;
//    }
//    public Play getPlay(){
//
//        return play;
//    }
//
//    public Settings getSettings() {
//
//        return settings;
//    }
}

