package main;

import game_options.Play;
import inputs.Keyinns;
import inputs.MouseMoves;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

public class Pannel extends JPanel {
    private int xval=200;
    private int yval=200;
    private BufferedImage bg_img;
    private BufferedImage bg_img_ele1;
    private BufferedImage bg_img_ele2;
    private BufferedImage bg_img_ele3;
    private BufferedImage bg_img_ele4;
    private MouseMoves mouse_moves;
    public Pannel(MainGame mainGame) {
        mouse_moves = new MouseMoves(this);
        importbg_img();
        setScreenSize();
        addKeyListener(new Keyinns(this));
        addMouseMotionListener(mouse_moves);
        addMouseListener(mouse_moves);
    }

    private void importbg_img() {
        InputStream is = getClass().getClassLoader().getResourceAsStream("assets/bg.jpg");
        InputStream is_2 = getClass().getClassLoader().getResourceAsStream("assets/play.png");
        InputStream is_3 = getClass().getClassLoader().getResourceAsStream("assets/settings_logo.png");
        InputStream is_4 = getClass().getClassLoader().getResourceAsStream("assets/ab_logo.png");
        InputStream is_5 = getClass().getClassLoader().getResourceAsStream("assets/red.png");
        if (is == null || is_2 == null || is_3 == null || is_4 == null || is_5 == null) {
            System.err.println("Image not found");
            return;
        }
        try {
            bg_img = ImageIO.read(is);
            bg_img_ele1 = ImageIO.read(is_2);
            bg_img_ele2 = ImageIO.read(is_3);
            bg_img_ele3 = ImageIO.read(is_4);
            bg_img_ele4 = ImageIO.read(is_5);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setScreenSize() {
        Dimension frame_size= new Dimension(800,550);
        setMinimumSize(frame_size);
        setPreferredSize(frame_size);
        setMaximumSize(frame_size);
    }
    public void switchScene() {

    }
    public void updateXval(int updates){
        this.xval=updates;
        repaint();
    }
    public void updateYval(int updates){
        this.yval+=updates;
        repaint();
    }
    public void setRectPos(int x, int y){
        this.xval=x;
        this.yval=y;
        repaint();
    }
    public void paint(Graphics g) {
        super.paintComponent(g);
//        g.drawImage(null,x,y,null);

        if (bg_img != null && bg_img_ele1 != null && bg_img_ele2 != null && bg_img_ele3 != null) {
            int play_width =150;
            int play_height = 90;
            int centerX = (getWidth() - play_width) / 2;
            int centerY = (getHeight() - play_height) / 2;
            g.drawImage(bg_img, 0,0, null);
//            g.drawImage(bg_img_ele1, xval, yval,play_width,play_height, null);
            g.drawImage(bg_img_ele1, centerX, 410,play_width,play_height, null);
            g.drawImage(bg_img_ele2, 20, 35,35,35, null);
            g.drawImage(bg_img_ele3,275,125,250,250,null);
//            g.drawImage(bg_img_ele4,275,125,250,250,null);
        }
    }

    public MainGame getMainGame() {
        return null;
    }
}
