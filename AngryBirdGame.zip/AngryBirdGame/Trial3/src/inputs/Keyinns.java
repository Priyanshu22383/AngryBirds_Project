package inputs;

import game_options.GameStats;
import main.Pannel;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Keyinns implements KeyListener {
    private Pannel pannel;

    public Keyinns(Pannel pannel) {
        this.pannel = pannel; // Correct assignment of the parameter to the instance variable
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        switch (GameStats.state) {
            case GAMELOADPAGE:
                pannel.getMainGame().getGameLoadPage().keyPressed(e);
                break;
            case PLAY:
                pannel.getMainGame().getPlay().keyPressed(e);
                break;
            case SETTINGS:
                pannel.getMainGame().getSettings().keyPressed(e);
                break;
            default:
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (GameStats.state) {
            case GAMELOADPAGE:
                pannel.getMainGame().getGameLoadPage().keyReleased(e);
                break;
            case PLAY:
                pannel.getMainGame().getPlay().keyReleased(e);
                break;
            case SETTINGS:
                pannel.getMainGame().getSettings().keyReleased(e);
                break;
            default:
                break;
        }
    }
}

