package Levels;

import game_options.Play;
import main.MainGame;
import main.Pannel;
import java.awt.*;
import java.awt.image.BufferedImage;

public class GameLevel {
    private Play game;
    private Pannel pannel;
    private BufferedImage bird_level;
    private BufferedImage bg_img_ele5;

    public GameLevel(Play game) {
        this.game = game;
    }

    public void draw(Graphics g) {
        if (bg_img_ele5 != null) {
            g.drawImage(bg_img_ele5, 200, 200, 50, 50, null);
        } else {
            System.err.println("Image not found");
        }
    }
    public void update_level() {

    }
}
