import main.MainGame;
import main.Pannel;

public class Main {
    private Pannel pannel;
    public static void main(String[] args){
        Pannel pannel = new Pannel();
        new MainGame(pannel);
    }
}
