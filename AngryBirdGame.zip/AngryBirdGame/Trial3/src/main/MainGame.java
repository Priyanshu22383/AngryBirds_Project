package main;

import Levels.GameLevel;
import entities.Bird;
import game_options.GameLoadPage;
import game_options.GameStats;
import game_options.Play;
import game_options.Settings;
import inputs.Keyinns;

import java.awt.*;

public class MainGame implements Runnable {
    private Window window;
    private Pannel pannel;
    private Bird bird;
    private GameLevel gameLevel;
    private Play play;
    private Settings settings;
    private GameLoadPage gameLoadPage;
    public MainGame(Pannel pannel){
        this.pannel = new Pannel();
        window = new Window(this.pannel);
        this.pannel.requestFocus();
        class_initiate();
    }

    private void class_initiate() {
        gameLoadPage = new GameLoadPage(this);
        settings = new Settings(this);
        play = new Play(this);
    }
    public void update() {
        switch (GameStats.state){
            case GAMELOADPAGE:
                gameLoadPage.update();
                break;
            case PLAY:
                gameLevel.update_level();
                bird.updates();
                break;
            case SETTINGS:
                break;
            default:
                break;
        }
    }
    public void render(Graphics g) {
        switch (GameStats.state){
            case GAMELOADPAGE:
                gameLoadPage.draw(g);
                break;
            case PLAY:
                play.draw(g);
                break;
            case SETTINGS:
                break;
            default:
                break;
        }
    }

    public void windowFocusLost() {
        if(GameStats.state==GameStats.PLAY){
            play.getPlay();
        }
    }

    @Override
    public void run() {
        for (int i = 0; i < 1; i++) {
            update();
            pannel.repaint(); // Triggers rendering
            try {
                Thread.sleep(16); // Approximately 60 FPS
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
    public GameLoadPage getGameLoadPage() {
        return gameLoadPage;
    }
    public Play getPlay() {
        return play;
    }
    public Settings getSettings() {
        return settings;
    }
    public static void main(String[] args) {
        Pannel pannel = new Pannel();
        MainGame mainGame = new MainGame(pannel);
        pannel.setMainGame(mainGame);
        Keyinns keyinns = new Keyinns(pannel);
        pannel.addKeyListener(keyinns);
    }

}


