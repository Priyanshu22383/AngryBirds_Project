package entities;

public abstract class Entity {
    protected float x, y;
    public Entity(float x, float y){
        this.x= this.x;
        this.y= this.y;
    }
}
