package entities;

import main.Pannel;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.InputStream;

public class Bird extends Entity {
    private BufferedImage bg_img_ele4;
    private Pannel pannel;
    private boolean fly;
    private boolean attack;
    public Bird(float x, float y) {
        super(x,y);
    }
    public void updates(){

    }
    public void render(Graphics g){
//        InputStream is_5 = getClass().getClassLoader().getResourceAsStream("assets/red.png");
//        Image bg_img_ele4 ;
//        try {
//            bg_img_ele4 = ImageIO.read(is_5);
//            g.drawImage(bg_img_ele4, 200, 200, 50, 50, null);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        BufferedImage bg_img_ele4 = pannel.getBgImgEle4();  // Get image from Pannel
        if (bg_img_ele4 != null) {
            g.drawImage(bg_img_ele4, 200, 200, 50, 50, null);
        } else {
            System.err.println("Image not found");
        }
    }
    private void update_bird_pos(){

    }
    private void setAttack(){

    }
    private void setFly(){

    }
}
