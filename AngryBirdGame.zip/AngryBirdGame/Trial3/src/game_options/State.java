package game_options;

import main.MainGame;

public class State {
    protected MainGame game;
    public State(MainGame game){
        this.game = this.game;
    }
    public MainGame getGame(){
        return game;
    }

}
