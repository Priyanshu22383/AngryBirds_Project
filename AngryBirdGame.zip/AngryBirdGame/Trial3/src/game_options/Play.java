package game_options;

import Levels.GameLevel;
import entities.Bird;
import main.MainGame;
import main.Pannel;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

public class Play extends State implements Statemethods{
    private Bird bird;
    private GameLevel gameLevel;
    private Pannel pannel;
    private void class_initiate() {
        bird = new Bird(200,200);
        gameLevel = new GameLevel(game.getPlay());
    }
    public Play(MainGame mainGame) {
        super(mainGame);
        class_initiate();
    }

    @Override
    public void update(Graphics g) {
        gameLevel.update_level();
        bird.updates();
    }

    @Override
    public void draw(Graphics g) {
        gameLevel.draw(g);
        bird.render(g);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getButton() == MouseEvent.BUTTON1) {

        }
        switch (GameStats.state) {
            case GAMELOADPAGE:
                pannel.getMainGame().getGameLoadPage().mouseClicked(e);
                break;
            case PLAY:
                pannel.getMainGame().getPlay().mouseClicked(e);
                break;
            case SETTINGS:
                pannel.getMainGame().getSettings().mouseClicked(e);
                break;
            default:
                break;
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A:
                System.out.println("Left");
                pannel.updateXval(-5);
                pannel.getMainGame().getPlay();
                break;
            case KeyEvent.VK_D:
                System.out.println("Right");
                pannel.updateXval(+5);
                pannel.getMainGame().getPlay();
                break;
            case KeyEvent.VK_W:
                System.out.println("Up");
                pannel.updateYval(-5);
                pannel.getMainGame().getPlay();
                break;
            case KeyEvent.VK_S:
                System.out.println("Down");
                pannel.updateYval(+5);
                pannel.getMainGame().getPlay();
                break;
            case KeyEvent.VK_SPACE:
                GameStats.state = GameStats.GAMELOADPAGE;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A:
                System.out.println("Left");
                pannel.updateXval(-5);
                pannel.getMainGame().getPlay();
                break;
            case KeyEvent.VK_D:
                System.out.println("Right");
                pannel.updateXval(+5);
                pannel.getMainGame().getPlay();
                break;
            case KeyEvent.VK_W:
                System.out.println("Up");
                pannel.updateYval(-5);
                pannel.getMainGame().getPlay();
                break;
            case KeyEvent.VK_S:
                System.out.println("Down");
                pannel.updateYval(+5);
                pannel.getMainGame().getPlay();
                break;
            case KeyEvent.VK_SPACE:
                GameStats.state = GameStats.GAMELOADPAGE;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    public void getPlay() {

    }
    public void windowFocusLost() {

    }
    public Bird getBird() {
        return bird;
    }
}
