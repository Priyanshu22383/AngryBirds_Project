package game_options;

import Levels.GameLevel;
import entities.Bird;
import main.MainGame;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

public class Settings extends State implements Statemethods {
    private Bird bird;
    private GameLevel gameLevel;

    public Settings(MainGame mainGame) {
        super(mainGame);
    }

    private void class_initiate() {
        bird = new Bird(200,200);
        gameLevel = new GameLevel(null);
    }

    @Override
    public void update(Graphics g) {

    }

    @Override
    public void draw(Graphics g) {
        gameLevel.draw(g);
        bird.render(g);
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }
}
