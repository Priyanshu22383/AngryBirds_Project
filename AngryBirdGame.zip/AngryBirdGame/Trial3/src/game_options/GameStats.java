package game_options;

public enum GameStats {
    GAMELOADPAGE,PLAY,SETTINGS;
    public static GameStats state = PLAY;
//    public static GameStats state_1 = GAMELOADPAGE;
//    public static GameStats state_2 = SETTINGS;
}
