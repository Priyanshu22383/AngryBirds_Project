package game_options;
import main.MainGame;
import main.Pannel;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

public class GameLoadPage extends State implements Statemethods{
    private Pannel pannel;

    public GameLoadPage(MainGame mainGame) {
        super(mainGame);
    }

    public void update() {

    }

    @Override
    public void update(Graphics g) {

    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.BLACK);
        g.drawString("Loading", 200, Pannel.HEIGHT/2);

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_ENTER){
            GameStats.state = GameStats.PLAY;
        }
//        switch (e.getKeyCode()) {
//            case KeyEvent.VK_A:
//                System.out.println("Left");
//                pannel.updateXval(-5);
//                break;
//            case KeyEvent.VK_D:
//                System.out.println("Right");
//                pannel.updateXval(+5);
//                break;
//            case KeyEvent.VK_W:
//                System.out.println("Up");
//                pannel.updateYval(-5);
//                break;
//            case KeyEvent.VK_S:
//                System.out.println("Down");
//                pannel.updateYval(+5);
//                break;
//        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }
}
