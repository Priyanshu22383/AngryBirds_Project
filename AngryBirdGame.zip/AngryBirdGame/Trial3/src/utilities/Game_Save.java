package utilities;

import java.awt.image.BufferedImage;

public class Game_Save {
    public static BufferedImage GetBirdLastSave(){
        return null;
    }
}
