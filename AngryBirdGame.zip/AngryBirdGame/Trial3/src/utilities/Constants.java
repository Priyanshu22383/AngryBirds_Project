package utilities;

public class Constants {
    public static class Player_Const{
        public static final int PLAY =1;
        public static final int PAUSE =2;
        public static final int EXIT =3;
        public static final int ATTACK =4;
        public static final int IDLE =5;
        public static final int FLYING =6;
        public static final int GROUND =7;
        public static final int HIT =8;
        public static final int TOT_BIRDS =9;
        public static int GetBirdsCount(int bird_action){
            switch (bird_action){
                case PLAY:
                case IDLE:
                    return 9;
                case PAUSE:
                    return 0;
                case EXIT:
                    return 0;
                case ATTACK:
                case FLYING:
                case GROUND:
                case HIT:
                    return 1;
                default:
                    return 0;
            }
        }
    }
}
